
See live at <https://examples.quarto.pub/css-chunk-options/>

## About this example

In this example, we are presenting how to pass options to cells that
does not use the `#` as comment character.
